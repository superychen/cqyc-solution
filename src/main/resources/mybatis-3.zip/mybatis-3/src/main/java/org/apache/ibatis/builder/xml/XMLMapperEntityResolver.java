/**
 *    Copyright 2009-2020 the original author or authors.
 *
 *    Licensed under the Apache License, Version 2.0 (the "License");
 *    you may not use this file except in compliance with the License.
 *    You may obtain a copy of the License at
 *
 *       http://www.apache.org/licenses/LICENSE-2.0
 *
 *    Unless required by applicable law or agreed to in writing, software
 *    distributed under the License is distributed on an "AS IS" BASIS,
 *    WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *    See the License for the specific language governing permissions and
 *    limitations under the License.
 */
package org.apache.ibatis.builder.xml;

import java.io.IOException;
import java.io.InputStream;
import java.util.Locale;

import org.apache.ibatis.io.Resources;
import org.xml.sax.EntityResolver;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;

/**
 * Offline entity resolver for the MyBatis DTDs.
 *
 * @author Clinton Begin
 * @author Eduardo Macarron
 */

/**
 * 解析xml文件中头文件信息
 * <?xml version="1.0" encoding="UTF-8" ?>
 *  <!DOCTYPE mapper
 *         PUBLIC "-//mybatis.org//DTD Mapper 3.0//EN"
 *         "http://mybatis.org/dtd/mybatis-3-mapper.dtd">
 * xml引入外部的dtd文件来对xml文件进行校验，例如上述中引用的dtd文件是http://mybatis.org/dtd/mybatis-3-mapper.dtd
 * 对于无网络的情况，此时XMLMapperEntityResolver来解决这个问题
 */
public class XMLMapperEntityResolver implements EntityResolver {

  private static final String IBATIS_CONFIG_SYSTEM = "ibatis-3-config.dtd";
  private static final String IBATIS_MAPPER_SYSTEM = "ibatis-3-mapper.dtd";
  private static final String MYBATIS_CONFIG_SYSTEM = "mybatis-3-config.dtd";
  private static final String MYBATIS_MAPPER_SYSTEM = "mybatis-3-mapper.dtd";

  private static final String MYBATIS_CONFIG_DTD = "org/apache/ibatis/builder/xml/mybatis-3-config.dtd";
  private static final String MYBATIS_MAPPER_DTD = "org/apache/ibatis/builder/xml/mybatis-3-mapper.dtd";

  /**
   * Converts a public DTD into a local one.
   * 将公共DTD转换为本地DTD
   * 在一个xml文档头部是这样的：
   * <?xml version="1.0" encoding="UTF-8" ?>
   * <!DOCTYPE mapper
   *         PUBLIC "-//mybatis.org//DTD Mapper 3.0//EN"
   *         "http://mybatis.org/dtd/mybatis-3-mapper.dtd">
   * @param publicId 为上述的 -//mybatis.org//DTD Mapper 3.0//EN
   *          The public id that is what comes after "PUBLIC"
   * @param systemId http://mybatis.org/dtd/mybatis-3-mapper.dtd
   *          The system id that is what comes after the public id.
   * @return The InputSource for the DTD
   *
   * @throws org.xml.sax.SAXException
   *           If anything goes wrong
   * 继承于org.xml.sax.EntityResolver，可通过该方法自定义给出DTD文档流的方式，而不是只能从互联网下载DTD文档
   * 找到本地的dtd文件，所以可以在无网络的环境下正常校验dtd
   */
  @Override
  public InputSource resolveEntity(String publicId, String systemId) throws SAXException {
    try {
      if (systemId != null) {
        //将systemI到转为全小写
        String lowerCaseSystemId = systemId.toLowerCase(Locale.ENGLISH);
        if (lowerCaseSystemId.contains(MYBATIS_CONFIG_SYSTEM) || lowerCaseSystemId.contains(IBATIS_CONFIG_SYSTEM)) {
          //说明这个是配置文档
          //直接把本地配置文档的dtd返回
          return getInputSource(MYBATIS_CONFIG_DTD, publicId, systemId);
        } else if (lowerCaseSystemId.contains(MYBATIS_MAPPER_SYSTEM) || lowerCaseSystemId.contains(IBATIS_MAPPER_SYSTEM)) {
          //为映射文件
          //直接把本地的映射文档的dtd文件返回
          return getInputSource(MYBATIS_MAPPER_DTD, publicId, systemId);
        }
      }
      return null;
    } catch (Exception e) {
      throw new SAXException(e.toString());
    }
  }

  private InputSource getInputSource(String path, String publicId, String systemId) {
    InputSource source = null;
    if (path != null) {
      try {
        InputStream in = Resources.getResourceAsStream(path);
        source = new InputSource(in);
        source.setPublicId(publicId);
        source.setSystemId(systemId);
      } catch (IOException e) {
        // ignore, null is ok
      }
    }
    return source;
  }

}
