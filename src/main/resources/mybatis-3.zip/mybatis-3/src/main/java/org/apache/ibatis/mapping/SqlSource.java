/**
 *    Copyright 2009-2019 the original author or authors.
 *
 *    Licensed under the Apache License, Version 2.0 (the "License");
 *    you may not use this file except in compliance with the License.
 *    You may obtain a copy of the License at
 *
 *       http://www.apache.org/licenses/LICENSE-2.0
 *
 *    Unless required by applicable law or agreed to in writing, software
 *    distributed under the License is distributed on an "AS IS" BASIS,
 *    WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *    See the License for the specific language governing permissions and
 *    limitations under the License.
 */
package org.apache.ibatis.mapping;

/**
 * Represents the content of a mapped statement read from an XML file or an annotation.
 * It creates the SQL that will be passed to the database out of the input parameter received from the user.
 *
 * @author Clinton Begin
 */

/**
 * sqlSource是一个解析实体类，他对应了mappedStatement中的sql语句
 * 4中实现类
 * DynamicSqlSource: 动态SQL语句。指含有动态SQL节点（如if节点），或者含有“${}”占位符语句
 * RawDqlSource: 原生SQL语句，指非动态语句，语句中可能含“#{}”占位符，但不含动态sql节点，也不含有“${}”占位符的语句
 * StaticSqlSource：静态语句。语句中可能含有“？”，直接提交给数据库执行
 * ProviderSqlSource: 通过注解映射的形式获取的Sql语句
 * DynamicSqlSource和RawDqlSource都会被处理成StaticSqlSource，然后通过StaticSqlSource的getBoundSQL方法得到SqlSource对象
 */
public interface SqlSource {

  /**
   * 获取一个BoundSql对象
   * @param parameterObject 参数对象
   * @return boundSql对象
   */
  BoundSql getBoundSql(Object parameterObject);

}
